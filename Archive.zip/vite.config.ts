import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
      "react": path.resolve(__dirname, "node_modules/react"),
      "react-dom": path.resolve(__dirname, "node_modules/react-dom"),
      "react/jsx-runtime": path.resolve(__dirname, "node_modules/react/jsx-runtime"),
      "react/jsx-dev-runtime": path.resolve(__dirname, "node_modules/react/jsx-dev-runtime"),
    },
    dedupe: ["react", "react-dom"], // ensure only one copy of each
  },
  esbuild: {
    jsx: 'automatic',
  },
  server: {
    port: 3000,
    open: true,
    hmr: { port: 3000, host: "localhost" },
    force: true,
    proxy: {
      '/api': { target: 'http://localhost:8000', changeOrigin: true, secure: false },
      '/sanctum': { target: 'http://localhost:8000', changeOrigin: true, secure: false },
      '/images': { target: 'http://localhost:8000', changeOrigin: true, secure: false },
      '/sample_images': { target: 'http://localhost:8000', changeOrigin: true, secure: false },
    },
  },
  build: {
    outDir: "dist",
    sourcemap: true,
    rollupOptions: {
      external: [],
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom'],
        },
      },
    },
  },
  optimizeDeps: {
    include: [
      "react", 
      "react-dom",
      "react/jsx-runtime",
      "react/jsx-dev-runtime"
    ],
    force: true,
  },
  define: {
    global: 'globalThis',
    __APP_VERSION__: JSON.stringify(Date.now()),
  },
});
