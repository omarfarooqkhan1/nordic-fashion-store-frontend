export interface Blog {
  id: number;
  title: string;
  slug: string;
  excerpt?: string;
  content?: string;
  featured_image?: string;
  status: 'draft' | 'published' | 'archived';
  author_name: string;
  author_email?: string;
  tags?: string[];
  views_count: number;
  likes_count: number;
  published_at?: string;
  formatted_published_date?: string;
  reading_time?: string;
  created_at: string;
  updated_at: string;
}

export interface BlogListResponse {
  data: Blog[];
  pagination: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    has_more_pages: boolean;
  };
}

export interface BlogCreateRequest {
  title: string;
  excerpt?: string;
  content: string;
  featured_image?: string;
  status: 'draft' | 'published' | 'archived';
  author_name: string;
  author_email?: string;
  tags?: string[];
  published_at?: string;
}

export interface BlogUpdateRequest extends Partial<BlogCreateRequest> {
  id: number;
}

export interface BlogStats {
  total_blogs: number;
  published_blogs: number;
  draft_blogs: number;
  archived_blogs: number;
  total_views: number;
  total_likes: number;
  recent_blogs: Array<{
    id: number;
    title: string;
    status: string;
    created_at: string;
  }>;
}

export interface BlogFilters {
  search?: string;
  tags?: string[];
  status?: 'draft' | 'published' | 'archived';
  per_page?: number;
  page?: number;
}
