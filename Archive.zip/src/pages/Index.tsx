import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import { useLanguage } from '@/contexts/LanguageContext';
import type { Product } from '@/types/Product';
import { fetchProducts } from '@/api/products';
import { LoadingState } from '@/components/common/LoadingState';
import { usePerformanceOptimization } from '@/hooks/usePerformanceOptimization';

const Index = () => {
  const { t } = useLanguage();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const { getQueryOptions, optimizeImageLoading } = usePerformanceOptimization();

  const heroImages = [
    '/lovable-uploads/731fa0a1-188d-4f8d-9829-7fde55e5e458.png',
    'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=1200&h=800&fit=crop',
    'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=1200&h=800&fit=crop',
    'https://images.unsplash.com/photo-1506629905814-b9daf261d74f?w=1200&h=800&fit=crop',
  ];

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % heroImages.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [heroImages.length]);

  const {
    data: products = [],
    isLoading,
    isError,
    error,
  } = useQuery({
    queryKey: ['products'],
    queryFn: fetchProducts,
    ...getQueryOptions(5 * 60 * 1000, 10 * 60 * 1000), // 5 min stale, 10 min cache
  });

  const featuredProducts = products.slice(0, 6);

  // Preload hero images for better LCP
  useEffect(() => {
    heroImages.forEach((image, index) => {
      if (index === 0) {
        // Preload the first hero image for LCP
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = image;
        document.head.appendChild(link);
      }
    });
  }, []);

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative h-[60vh] min-h-[350px] md:h-[80vh] md:min-h-[600px] overflow-hidden">
        <div className="absolute inset-0">
          {heroImages.map((image, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentImageIndex ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <img
                src={image}
                alt={`Nord Flex craftsmanship ${index + 1}`}
                className="w-full h-full object-cover"
                loading={index === 0 ? 'eager' : 'lazy'}
                fetchPriority={index === 0 ? 'high' : 'auto'}
                sizes="100vw"
              />
            </div>
          ))}
          <div className="absolute inset-0 bg-black/40"></div>
        </div>

        <div className="relative z-10 h-full flex items-center">
          <div className="container mx-auto px-2 sm:px-4">
            <div className="max-w-2xl md:max-w-4xl mx-auto text-center text-white">
              <div className="mb-6">
                <span className="inline-block px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-xs sm:text-sm font-medium tracking-wider uppercase mb-4">
                  {t('hero.authentic')}
                </span>
              </div>
              <h1 className="text-2xl sm:text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
                {t('hero.title')}
                <span className="block text-lg sm:text-3xl md:text-5xl lg:text-6xl mt-2 opacity-90">
                  {t('hero.from')}
                </span>
              </h1>
              <p className="text-base sm:text-lg md:text-xl lg:text-2xl mb-8 max-w-2xl md:max-w-3xl mx-auto opacity-90 leading-relaxed">
                {t('hero.description')}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/products">
                  <Button size="lg" className="bg-white text-black hover:bg-white/90 font-semibold px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200 hover:border-gray-300">
                    {t('hero.explore')}
                  </Button>
                </Link>
                <Link to="/about">
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-2 border-white text-white bg-black/20 hover:bg-white hover:text-black font-semibold px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg backdrop-blur-sm transition-all duration-300"
                  >
                    {t('hero.story')}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-4 sm:bottom-8 left-1/2 transform -translate-x-1/2 z-20">
          <div className="flex space-x-2">
            {heroImages.map((_, index) => (
              <button
                key={index}
                className={`w-2 h-2 sm:w-3 sm:h-3 rounded-full transition-all duration-300 ${
                  index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                }`}
                onClick={() => setCurrentImageIndex(index)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-10 sm:py-16">
        <div className="container mx-auto px-2 sm:px-4">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-8 sm:mb-12 text-foreground">
            {t('common.featured')}
          </h2>

          {isLoading ? (
            <LoadingState message={t('common.loading')} className="py-12" />
          ) : isError ? (
            <p className="text-center text-red-600 text-base sm:text-lg">{t('toast.error')}: {(error as Error).message}</p>
          ) : featuredProducts.length === 0 ? (
            <p className="text-center text-base sm:text-lg">{t('products.all')} - {t('cart.empty')}</p>
          ) : (
            <Carousel className="w-full max-w-4xl md:max-w-6xl mx-auto" opts={{ align: 'start', loop: true }}>
              <CarouselContent className="-ml-2 md:-ml-4">
                {featuredProducts.map((product) => (
                  <CarouselItem key={product.id} className="pl-2 md:pl-4 basis-4/5 xs:basis-1/2 md:basis-1/2 lg:basis-1/3">
                    <Card className="bg-card border-border overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group">
                      <Link to={`/product/${product.id}`}>
                        <div className="aspect-square bg-muted relative overflow-hidden">
                          {product.images.length > 0 ? (
                            <img
                              src={product.images[0].url}
                              alt={product.images[0].alt_text || product?.name || 'Product'}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                              onError={(e) => {
                                e.currentTarget.src = '/placeholder.svg';
                              }}
                              loading="lazy"
                              sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <img 
                                src="/placeholder.svg" 
                                alt="No image available" 
                                className="w-full h-full object-cover opacity-50"
                                loading="lazy"
                                sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                              />
                            </div>
                          )}
                        </div>
                      </Link>
                      <CardContent className="p-4 sm:p-6">
                        <Link to={`/product/${product.id}`}>
                          <div>
                            <h3 className="text-base sm:text-xl font-semibold mb-1 sm:mb-2 text-foreground hover:text-primary transition-colors">{product?.name || 'Unnamed Product'}</h3>
                            <p className="text-xs sm:text-sm text-muted-foreground capitalize mb-1 sm:mb-2">{product?.category?.name || 'Uncategorized'}</p>
                          </div>
                        </Link>
                        <p className="text-xs sm:text-sm text-muted-foreground mb-2 sm:mb-4 line-clamp-2">{product.description}</p>
                        <div className="flex flex-col sm:flex-row justify-between items-center gap-2 sm:gap-0">
                          <div className="flex items-center gap-2">
                            <span className="text-lg sm:text-2xl font-bold text-primary">€{product.price}</span>
                          </div>
                          <Button
                            variant="outline"
                            asChild
                            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300 w-full sm:w-auto"
                          >
                            <Link to={`/product/${product.id}`}>
                              {t('common.viewDetails')}
                            </Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="border-primary text-primary hover:bg-primary hover:text-primary-foreground" />
              <CarouselNext className="border-primary text-primary hover:bg-primary hover:text-primary-foreground" />
            </Carousel>
          )}
        </div>
      </section>
    </div>
  );
};

export default Index;