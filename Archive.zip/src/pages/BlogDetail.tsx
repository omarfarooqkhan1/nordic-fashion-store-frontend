import React from 'react';
import { Helmet } from 'react-helmet-async';
import BlogDetail from '@/components/Blog/BlogDetail';

const BlogDetailPage: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Blog Post - Nordic Fashion Store</title>
        <meta name="description" content="Read our latest blog post about Nordic fashion and lifestyle." />
      </Helmet>
      
      <BlogDetail />
    </>
  );
};

export default BlogDetailPage;
