import React from 'react';
import { Helmet } from 'react-helmet-async';
import BlogList from '@/components/Blog/BlogList';

const Blog: React.FC = () => {
  // Scroll to top when component mounts
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Helmet>
        <title>Blog - Nordic Fashion Store</title>
        <meta name="description" content="Read our latest blog posts about fashion, style tips, and Nordic lifestyle." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Our Blog
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover the latest in Nordic fashion, style tips, and lifestyle inspiration. 
            Stay updated with our expert insights and trending topics.
          </p>
        </div>

        <BlogList />
      </div>
    </>
  );
};

export default Blog;
