import React from 'react';

const TestComponent: React.FC = () => {
  return <div>Test Component - React is working</div>;
};

export default TestComponent;
